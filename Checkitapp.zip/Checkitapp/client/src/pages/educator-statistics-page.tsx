import { EducatorStatistics } from "@/components/educator-statistics";

export default function EducatorStatisticsPage() {
  return <EducatorStatistics />;
}