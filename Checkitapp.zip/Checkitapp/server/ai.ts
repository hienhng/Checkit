import OpenAI from "openai";
import { z } from "zod";

// Check if API key is available
const apiKey = process.env.OPENAI_API_KEY;

// Initialize the OpenAI client only if API key is available
// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
let openai: OpenAI | null = null;

try {
  if (apiKey) {
    openai = new OpenAI({ apiKey });
    console.log("OpenAI client initialized successfully");
  } else {
    console.warn("OPENAI_API_KEY is not set. AI features will be unavailable.");
  }
} catch (error) {
  console.error("Error initializing OpenAI client:", error);
}

/**
 * Check if the OpenAI API key is configured
 */
export function isOpenAIConfigured(): boolean {
  return !!openai;
}

/**
 * Generate definitions for words
 */
export async function generateDefinitions(words: string[]): Promise<Record<string, string>> {
  try {
    if (!openai) {
      throw new Error("OpenAI API key is not configured");
    }

    const prompt = `
      For each of the following words, provide a clear, concise definition suitable for a vocabulary learning platform.
      Format the response as a JSON object where each key is the word and each value is its definition.
      Make definitions easy to understand for learners.
      
      Words: ${words.join(", ")}
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No content returned from OpenAI");
    }

    // Parse the JSON response
    const definitions = JSON.parse(content);
    return definitions;
  } catch (error: any) {
    console.error("Error generating definitions:", error);
    
    // Check for rate limit or quota errors
    if (error.status === 429 || (error.error && error.error.code === 'insufficient_quota')) {
      throw new Error("API quota exceeded. Please try again later or contact your administrator to update the API key.");
    } else if (error.status === 401 || error.status === 403) {
      throw new Error("API key authentication failed. Please check your API key.");
    } else {
      throw new Error("Failed to generate definitions. Please try again later.");
    }
  }
}

/**
 * Analyze a passage and extract potential vocabulary words
 */
export async function analyzePassage(passage: string, count: number = 10): Promise<string[]> {
  try {
    if (!openai) {
      throw new Error("OpenAI API key is not configured");
    }

    const prompt = `
      Analyze the following passage and identify ${count} words that would be valuable for vocabulary learning.
      Focus on words that are:
      1. Important for understanding the passage
      2. Likely to appear in other academic or literary contexts
      3. Appropriate for expanding a student's vocabulary
      
      Return only a JSON array of these words, with no additional text or explanation.
      
      Passage:
      ${passage}
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No content returned from OpenAI");
    }

    // Parse the JSON response
    const result = JSON.parse(content);
    return Array.isArray(result.words) ? result.words : [];
  } catch (error) {
    console.error("Error analyzing passage:", error);
    throw new Error("Failed to analyze passage");
  }
}

/**
 * Grade a student's definition against the correct definition
 */
export async function gradeDefinition(
  word: string,
  studentDefinition: string,
  correctDefinition?: string
): Promise<{
  isCorrect: boolean;
  confidence: number;
  feedback: string;
  suggestedCorrectDefinition?: string;
}> {
  try {
    if (!openai) {
      throw new Error("OpenAI API key is not configured");
    }

    // If no correct definition is provided, generate one
    let definitionToCheck = correctDefinition;
    if (!definitionToCheck) {
      const definitions = await generateDefinitions([word]);
      definitionToCheck = definitions[word];
    }

    const prompt = `
      Grade this student's definition of the word "${word}".
      
      Student definition: "${studentDefinition}"
      Correct definition: "${definitionToCheck}"
      
      Provide a JSON response with the following fields:
      - isCorrect: boolean (true if the student's definition captures the essence of the word)
      - confidence: number (between 0 and 1, indicating your confidence in the assessment)
      - feedback: string (constructive feedback for the student)
      - suggestedCorrectDefinition: string (optional, only if the correct definition provided seems incomplete)
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No content returned from OpenAI");
    }

    // Parse the JSON response
    const grading = JSON.parse(content);
    
    // Validate the response with Zod
    const gradingSchema = z.object({
      isCorrect: z.boolean(),
      confidence: z.number().min(0).max(1),
      feedback: z.string(),
      suggestedCorrectDefinition: z.string().optional(),
    });

    return gradingSchema.parse(grading);
  } catch (error) {
    console.error("Error grading definition:", error);
    throw new Error("Failed to grade definition");
  }
}

/**
 * Generate example sentences for vocabulary words
 */
export async function generateExampleSentences(words: string[], count: number = 1): Promise<Record<string, string[]>> {
  try {
    if (!openai) {
      throw new Error("OpenAI API key is not configured");
    }

    const prompt = `
      For each of the following words, provide ${count} example sentence(s) that clearly demonstrate the meaning and usage of the word.
      Format the response as a JSON object where each key is the word and each value is an array of sentences.
      Make the sentences appropriate for educational purposes and suitable for vocabulary learning.
      
      Words: ${words.join(", ")}
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No content returned from OpenAI");
    }

    // Parse the JSON response
    const sentences = JSON.parse(content);
    return sentences;
  } catch (error) {
    console.error("Error generating example sentences:", error);
    throw new Error("Failed to generate example sentences");
  }
}

/**
 * Generate personalized learning suggestions based on student performance
 */
export async function generateLearningStrategies(words: string[], studentPerformance: Record<string, boolean>): Promise<{
  strengths: string[];
  weaknesses: string[];
  strategies: string[];
}> {
  try {
    if (!openai) {
      throw new Error("OpenAI API key is not configured");
    }

    const wordsCorrect = Object.entries(studentPerformance)
      .filter(([_, isCorrect]) => isCorrect)
      .map(([word]) => word);
    
    const wordsIncorrect = Object.entries(studentPerformance)
      .filter(([_, isCorrect]) => !isCorrect)
      .map(([word]) => word);

    const prompt = `
      Analyze a student's vocabulary performance and provide personalized learning strategies.
      
      Words the student knew correctly: ${wordsCorrect.join(", ")}
      Words the student had difficulty with: ${wordsIncorrect.join(", ")}
      
      Provide a JSON response with the following fields:
      - strengths: array of strings (areas where the student shows strength)
      - weaknesses: array of strings (areas where the student needs improvement)
      - strategies: array of strings (specific learning strategies tailored to this student)
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No content returned from OpenAI");
    }

    // Parse the JSON response
    const strategies = JSON.parse(content);
    
    // Validate the response with Zod
    const strategiesSchema = z.object({
      strengths: z.array(z.string()),
      weaknesses: z.array(z.string()),
      strategies: z.array(z.string()),
    });

    return strategiesSchema.parse(strategies);
  } catch (error) {
    console.error("Error generating learning strategies:", error);
    throw new Error("Failed to generate learning strategies");
  }
}

/**
 * Generate a passage that includes all the provided vocabulary words
 */
export async function generatePassageFromWords(
  words: string[], 
  options: { 
    topic?: string; 
    gradeLevel?: string;
    paragraphCount?: number;
    style?: string;
  } = {}
): Promise<string> {
  try {
    if (!openai) {
      throw new Error("OpenAI API key is not configured");
    }

    // Set defaults for options
    const topic = options.topic || "general knowledge";
    const gradeLevel = options.gradeLevel || "middle school";
    const paragraphCount = options.paragraphCount || 1;
    const style = options.style || "educational";

    const prompt = `
      Create an engaging and coherent ${style} passage (${paragraphCount} paragraph(s)) about ${topic} at a ${gradeLevel} reading level
      that naturally incorporates ALL of the following vocabulary words. The passage should flow naturally and not feel forced.
      
      Vocabulary words to include: ${words.join(", ")}
      
      Important:
      1. Use ALL the listed words in their exact form
      2. Make the passage coherent and educational
      3. Ensure the passage is appropriate for ${gradeLevel} students
      4. The passage should be between 100-300 words, depending on the number of vocabulary words
      5. Return ONLY the passage, with no explanations, titles, or metadata
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No content returned from OpenAI");
    }

    return content.trim();
  } catch (error: any) {
    console.error("Error generating passage:", error);
    
    // Check for rate limit or quota errors
    if (error.status === 429 || (error.error && error.error.code === 'insufficient_quota')) {
      throw new Error("API quota exceeded. Please try again later or contact your administrator to update the API key.");
    } else if (error.status === 401 || error.status === 403) {
      throw new Error("API key authentication failed. Please check your API key.");
    } else {
      throw new Error("Failed to generate passage from vocabulary words. Please try again later.");
    }
  }
}